MONARK BRAND KIT
================

Guidelines: https://www.monark.io/brand
Tagline: Fostering Collaboration within the Web3 Community

WHAT'S INSIDE
  logos/svg/     Every lockup as SVG. Use these whenever you can.
  logos/png/     The same files as transparent PNGs, 512, 1024 and 2048px wide.
  credit/        "Built with Monark" badges for independent products (EN and FR).
  tokens/        Colour and type tokens (CSS, W3C design tokens, Tokens Studio).

  File names say which background a logo is for:
  -on-light = dark lettering, for cream or white backgrounds.
  -on-dark  = white lettering, for espresso or dark backgrounds.

LOGO RULES
  - Use the files as they are. Never retype, redraw, recolour, stretch,
    rotate, outline, add effects to or animate the logo.
  - Clear space: at least half the height of the butterfly mark, on every side.
  - Minimum size: the mark 20px tall (16px as a favicon); the horizontal
    logo 120px wide. Measured on the drawing, not the file's padding.
  - The colour logo goes on plain cream, white or espresso. On photos,
    orange or busy backgrounds, use a mono version.
  - The mark's gradient (#ED2723 to #FBA60B) belongs to the logo.
    It is the only gradient in the brand.

COLOUR
  Monark orange   #F88D10  The accent: fills, icons, focus, one main button per screen.
                            Text on orange is always dark (7.9:1), never white (2.4:1).
                            Never set orange text on cream (2.3:1): use orange ink.

  Cream (light theme)
  Background     #FFF9F3  Page background
  Card           #FFFEFC  Cards and panels
  Surface        #F7ECE4  Quiet areas and chips
  Border         #E9DFD7  Dividers and outlines
  Text           #15110E  Headings and body text (18:1)
  Muted text     #625952  Captions and hints (6.5:1)
  Orange ink     #B65000  Orange text and links (4.9:1)
  Red accent     #EF3620  Charts and small highlights

  Espresso (dark theme)
  Background     #1A0B02  Page background
  Card           #26170A  Cards and panels
  Surface        #36281D  Quiet areas and chips
  Border         #433529  Dividers and outlines
  Text           #FFF0E4  Headings and body text (17:1)
  Muted text     #B8A79A  Captions and hints (7.5:1)
  Orange ink     #F88D10  Orange text and links (8.1:1)
  Red accent     #FC452F  Charts and small highlights

TYPE
  Nunito Sans for all text (400, 600, 700, 800). Headings: Title Case in
  English, sentence case in French. Buttons: sentence case in both.
  Free from Google Fonts: https://fonts.google.com/specimen/Nunito+Sans
  Fonts are not included in this kit.
  The MONARK wordmark is set in Trajan Pro, a commercial font that is not
  provided. Don't set any other text in Trajan or its lookalike Cinzel.

PRODUCTS
  Monark products: the colour mark (28px), a 10px gap, then the product
  name in Nunito Sans 800 at 18px, on one line. No product logos.
  Independent products: a small "Built with Monark" credit in the footer,
  linking to https://www.monark.io.

CONTACT
  contact@monark.io  ·  https://discord.gg/TvhrbFCp8T
